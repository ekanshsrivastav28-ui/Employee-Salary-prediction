# Salary-Prediction-Project

# Dataset Used
The StackOverflow 2023 survey of developers was used to train the model after extracting additional features and preprocessing all the used features.
Link: https://insights.stackoverflow.com/survey

# Run The Predictor
1. Clone the repository and CD into the python files folder
2. On the terminal, write streamlit run app.y
3. Open the link shown in the terminal where the Web Application is visible
4. Choose the inputs using the select boxes and the sliders
5. Click on Predict Salary to see the predicted annual compensation in dollars based on the input.



